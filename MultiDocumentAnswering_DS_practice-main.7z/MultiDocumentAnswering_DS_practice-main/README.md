# MultiDocumentAnswering

Experiment to answer questions from arbitrary number of sources

## DISCLAIMER: INFORMATIONAL AND EXPERIMENTATION PURPOSES ONLY

Any summarizations or answers made with this code come with no warranty (see MIT license) and should not be used for financial, medical, legal, or any other critical applications.
